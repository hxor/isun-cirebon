<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AgendaGallery extends Model
{
    protected $fillable = ['agenda_id', 'path'];
}
